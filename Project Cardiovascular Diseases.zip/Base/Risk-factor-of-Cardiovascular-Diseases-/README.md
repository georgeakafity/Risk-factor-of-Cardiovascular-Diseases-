# Risk factor of Cardiovascular Diseases 
Cardiovascular diseases continue to challenge global health sustainability. This data exercise looks to contribute to that.
