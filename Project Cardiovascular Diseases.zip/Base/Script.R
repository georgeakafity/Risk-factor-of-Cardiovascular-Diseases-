library(tidyverse)
cvd <- read.csv("CVD Dataset.csv")
dim(cvd)
str(cvd)
View(cvd)
head(cvd)
library(janitor)
cvd <- cvd %>%
  clean_names()
colnames(cvd)
cvd_clean <- cvd %>%
  drop_na(
    age,
    weight_kg,
    height_m,
    systolic_bp,
    diastolic_bp,
    total_cholesterol_mg_d_l,
    blood_pressure_mm_hg,
    cvd_risk_score,
    abdominal_circumference_cm,
    fasting_blood_sugar_mg_d_l,
    family_history_of_cvd,
    smoking_status,
    blood_pressure_category,
    estimated_ldl_mg_d_l,
    diabetes_status,
    height_cm,
    hdl_mg_d_l,
    physical_activity_level,
    waist_to_height_ratio,
    bmi
  )
cvd_clean <- cvd %>%
  filter(
    age > 18 & age < 90,
    weight_kg > 35 & weight_kg < 200,
    height_m > 1.4 & height_m < 2.1
  )
colnames(cvd)
cvd_clean <- cvd_clean %>%
  filter(
    if_all(
      where(is.numeric),
      ~ .x >= 0 & .x <= quantile(.x, 0.99, na.rm = TRUE)
    )
  )

cvd_clean <- cvd_clean %>%
  mutate(
    bmi_category = case_when(
      bmi < 18.5 ~ "Underweight",
      bmi >= 18.5 & bmi < 25 ~ "Normal",
      bmi >= 25 & bmi < 30 ~ "Overweight",
      bmi >= 30 ~ "Obese",
      TRUE ~ NA_character_
    )
  )
cvd_clean <- cvd_clean %>%
  mutate(
    hypertension = if_else(
      systolic_bp >= 140 | diastolic_bp >= 90,
      "Yes",
      "No"
    )
  )
cvd_clean <- cvd_clean %>%
  mutate(
    sex = as.factor(sex),
    bmi_category = as.factor(bmi_category),
    hypertension = as.factor(hypertension)
  )
summary(cvd_clean)
str(cvd_clean)
anyNA(cvd_clean)
cvd_clean <- cvd_clean %>%
  mutate(
    sex = as.factor(sex),
    bmi_category = as.factor(bmi_category),
    hypertension = as.factor(hypertension)
  )
write_csv(cvd_clean, "cvd_clean_final.csv")
cvd_clean %>%
  summarise(
    mean_age = mean(age),
    sd_age = sd(age),
    mean_bmi = mean(bmi),
    mean_systolic_bp = mean(systolic_bp),
    mean_diastolic_bp = mean(diastolic_bp),
    mean_cholesterol = mean(total_cholesterol_mg_d_l),
    mean_height_m = mean(height_m),
    mean_fasting_blood_sugar_mg_d_l = mean(fasting_blood_sugar_mg_d_l),
    mean_abdominal_circumference_cm = mean(abdominal_circumference_cm)
  )
table(cvd_clean$bmi_category)
table(cvd_clean$hypertension)
table(cvd_clean$sex)
library(ggplot2)
ggplot(cvd_clean, aes(x = age)) +
  geom_histogram(bins = 30) +
  labs(
    title = "Age Distribution of Participants",
    x = "Age (years)",
    y = "Count"
  )
ggplot(cvd_clean, aes(x = bmi_category)) +
  geom_bar() +
  labs(
    title = "BMI Category Distribution",
    x = "BMI Category",
    y = "Count"
  )
ggplot(cvd_clean, aes(x = sex)) +
  geom_bar() +
  labs(
    title = "sex",
    x = "sex",
    y = "Count"
  )
