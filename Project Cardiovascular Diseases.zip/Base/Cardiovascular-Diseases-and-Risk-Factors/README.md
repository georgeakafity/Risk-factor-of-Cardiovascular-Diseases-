# Cardiovascular Diseases and Risk Factors
Cardiovascular diseases continue to challenge global health sustainability. This data exercise looks to contribute to that.
